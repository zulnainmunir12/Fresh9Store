import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:fresh9_rider/core/model/base_model.dart';
import 'package:fresh9_rider/core/model/login_model.dart';
import 'package:fresh9_rider/core/model/product.dart';
import 'package:fresh9_rider/core/model/store_model.dart';
import 'package:fresh9_rider/core/model/user_info_model.dart';
import 'package:fresh9_rider/ui/shared/shared_preference.dart';
import 'package:http/http.dart' as http;
import 'package:fresh9_rider/core/component/endpoints.dart';
import 'package:fresh9_rider/ui/shared/ui_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Api {
  final client = http.Client();
  final Duration timeOutDuration = Duration(seconds: 30);

  int attempt = 1;
  int totalAttempt = 3;

  onException(dynamic error) {
    print(error);
    if (error is SocketException) {
      return UIHelper.noConnection;
    }

    if (error is TimeoutException) {
      return UIHelper.timeOut;
    } else {
      if (attempt > totalAttempt) {
        attempt = 1;
      }
      attempt++;
      if (attempt <= totalAttempt) {
        print("Attempt $attempt");
        return false;
      } else {
        return UIHelper.sthWentWrong;
      }
    }
  }

  Future<LoginModel> login(Map body) async {
    print(body);
    String url = loginUrl;
    print("url : $url");
    final stopwatch = new Stopwatch()..start();
    try {
      var response = await http
          .post(
            Uri.parse(url),
            headers: {
              'Accept': '*/*',
            },
            body: body,
          )
          .timeout(timeOutDuration);

//      var userInfo = await http.get(
//        Uri.parse("http://40.121.147.31:10000/users/information"),
//        headers: {
//          'Accept': '*/*',
//          "authorization": jsonDecode(response.body)["message"]["token"]
//        },
//      ).timeout(timeOutDuration);

      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from Login: ${response.body}');
//      print(userInfo.body);
//      Map userData = jsonDecode(response.body)["user"];
//      userData["token"] = jsonDecode(response.body)["message"]["token"];
//      print(userData);
//      userData["user"] = jsonDecode(userInfo.body)["message"]["user"];
//      userData["user"]["storeDetail"] = jsonDecode(userInfo.body)["store"];
      SharedPreferences sharedPreference =
          await SharedPreferences.getInstance();
      sharedPreference.setString(SharedPreference.user, response.body);

      return LoginModel.fromJson(jsonDecode(response.body));
    } catch (e) {
      var data = onException(e);
      return data is bool
          ? LoginModel.withError(UIHelper.sthWentWrong)
          : LoginModel.withError(data);
    }
  }

  Future<BaseModel> getMyOrders(token, userId) async {
    String url = getOrders + userId;
    print("url : $url");
    final stopwatch = new Stopwatch()..start();
    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {'Accept': '*/*', "Authorization": token},
      ).timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from Orders: ${response.body}');
      return BaseModel(body: response.body);
    } catch (e) {
      var serverError = onException(e);
      return BaseModel.withError(serverError);
    }
  }

  Future<BaseModel> getMyRiders(token, userId) async {
    String url = getRidersUrl + userId;
    print("url : $url");
    final stopwatch = Stopwatch()..start();
    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {'Accept': '*/*', "Authorization": token},
      ).timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from getMyRiders: ${response.body}');

      return BaseModel(
        body: response.body,
      );
    } catch (e) {
      var serverError = onException(e);
      return serverError is bool
          ? BaseModel.withError(UIHelper.sthWentWrong)
          : BaseModel.withError(serverError);
    }
  }

  Future<BaseModel> getMyProducts(token, userId) async {
    String url = storeUrl + userId + "/products";
    print("url : $url");
    final stopwatch = Stopwatch()..start();
    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {'Accept': '*/*', "Authorization": token},
      ).timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from getMyRiders: ${response.body}');

      return BaseModel(
        body: response.body,
      );
    } catch (e) {
      var serverError = onException(e);
      return serverError is bool
          ? BaseModel.withError(UIHelper.sthWentWrong)
          : BaseModel.withError(serverError);
    }
  }

  Future<BaseModel> getMyActiveRiders(token, userId) async {
    String url = getActiveRidersUrl + userId;
    print("url : $url");
    final stopwatch = Stopwatch()..start();
    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {'Accept': '*/*', "Authorization": token},
      ).timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from getMy ActiveRiders: ${response.body}');

      return BaseModel(
        body: response.body,
      );
    } catch (e) {
      var serverError = onException(e);
      return serverError is bool
          ? BaseModel.withError(UIHelper.sthWentWrong)
          : BaseModel.withError(serverError);
    }
  }

  Future<BaseModel> createRider(Map body) async {
    String url = signupUrl;
    print("url : $url");
    final stopwatch = Stopwatch()..start();
    try {
      var response = await http.post(
        Uri.parse(url),
        body: body,
        headers: {
          'Accept': '*/*',
        },
      ).timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from register Rider: ${response.body}');
      return BaseModel(
          body: UserInfoModel.fromJson(jsonDecode(response.body)["message"]));
    } catch (e) {
      var serverError = onException(e);
      return serverError is bool
          ? BaseModel.withError(UIHelper.sthWentWrong)
          : BaseModel.withError(serverError);
    }
  }

  Future<BaseModel> updateRiderStatus(
      String userId, Map status, String token) async {
    String url = userUrl + userId;
    print("url : $url");
    print(token);
    print({"active": status});
    final stopwatch = Stopwatch()..start();
    try {
      var response = await http
          .put(Uri.parse(url),
              headers: {'Accept': '*/*', "Authorization": token}, body: status)
          .timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from updateRiderStatus Rider: ${response.body}');
      return BaseModel(
          body: UserInfoModel.fromJson(jsonDecode(response.body)["message"]));
    } catch (e) {
      var serverError = onException(e);
      return serverError is bool
          ? BaseModel.withError(UIHelper.sthWentWrong)
          : BaseModel.withError(serverError);
    }
  }

  Future<BaseModel> updateStoreStatus(
      String userId, Map status, String token) async {
    String url = storeUrl + userId;
    print("url : $url");
    print({"active": status});
    final stopwatch = Stopwatch()..start();
    try {
      var response = await http
          .put(Uri.parse(url),
              headers: {'Accept': '*/*', "Authorization": token}, body: status)
          .timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from updateRiderStatus Rider: ${response.body}');
      return BaseModel(body: StoreModel.fromJson(jsonDecode(response.body)));
    } catch (e) {
      var serverError = onException(e);
      return serverError is bool
          ? BaseModel.withError(UIHelper.sthWentWrong)
          : BaseModel.withError(serverError);
    }
  }

  Future<BaseModel> updateProductStatus(
      String storeId, String productId, Map status, String token) async {
    String url = storeUrl + storeId + "/updatedProduct/" + productId;
    print("url : $url");
    print({"active": status});
    final stopwatch = Stopwatch()..start();
    try {
      var response = await http
          .put(Uri.parse(url),
              headers: {'Accept': '*/*', "Authorization": token}, body: status)
          .timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from updateRiderStatus Rider: ${response.body}');
      return BaseModel(body: Product.fromJson(jsonDecode(response.body)));
    } catch (e) {
      var serverError = onException(e);
      return serverError is bool
          ? BaseModel.withError(UIHelper.sthWentWrong)
          : BaseModel.withError(serverError);
    }
  }

  Future<BaseModel> getUserInfo(String token) async {
//    String url = userUrl + userId;
//    print("url : $url");
//    print({"active": status});
    final stopwatch = Stopwatch()..start();
    try {
      var response = await http.get(
        Uri.parse("http://40.121.147.31:10000/users/information"),
        headers: {'Accept': '*/*', "authorization": token},
      ).timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from updateRiderStatus Rider: ${response.body}');
      Map userData = jsonDecode(response.body)["message"];
      print("1");
      print(userData);
      userData["user"] = jsonDecode(response.body)["message"]["user"];
      print("2");
      print(userData);
      userData["user"]["storeDetail"] = jsonDecode(response.body)["store"];
      print("3");
      print(userData);
      return BaseModel(body: UserInfoModel.fromJson(userData["user"]));
    } catch (e) {
      var serverError = onException(e);
      return serverError is bool
          ? BaseModel.withError(UIHelper.sthWentWrong)
          : BaseModel.withError(serverError);
    }
  }

  Future updateOrder(token, orderId, Map status) async {
    String url = orderUrl + orderId;
    print("url : $url");
    final stopwatch = new Stopwatch()..start();
    try {
      var response = await http.put(Uri.parse(url),
          headers: {'Accept': '*/*', "Authorization": token},
          body: status).timeout(timeOutDuration);
      print('Time Taken - ${stopwatch.elapsed}');
      print('The response from Order cancelled: ${response.body}');
      return BaseModel(body: response.body);
    } catch (e) {
      var serverError = onException(e);
      return BaseModel.withError(serverError);
    }
  }
}
