enum ViewState { loading, error, idle }

enum OrderType { Pickup, Delivery }

enum AnswerType { Yes, No, NoAnswer }

enum Payment { Cash, Card, SavedCard}
