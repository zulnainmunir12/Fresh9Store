import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:fresh9_rider/core/model/base_model.dart';
import 'package:fresh9_rider/core/model/order_model.dart';
import 'package:fresh9_rider/core/model/user_info_model.dart';
import 'package:fresh9_rider/core/service/api.dart';
import 'package:fresh9_rider/core/enums/enums.dart';
import 'package:fresh9_rider/core/service/auth_service.dart';
import 'package:fresh9_rider/core/service/navigation_service.dart';
import 'package:fresh9_rider/core/viewmodel/custom_base_view_model.dart';
import 'package:fresh9_rider/locator.dart';
import 'package:fresh9_rider/ui/router.dart';
import 'package:fresh9_rider/ui/shared/shared_preference.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class OrderViewModel extends CustomBaseViewModel {
  final NavigationService _navigationService = locator<NavigationService>();
  final AuthService _authService = locator<AuthService>();
  final Api _api = locator<Api>();
  UserInfoModel _userInfoModel;
  UserInfoModel get userInfoModel => _userInfoModel;
  List orderList;
  List<UserInfoModel> ridersList = [];

  String orderStatus;

  navigateToAppServices() {
    _navigationService.navigateToAndClearAll(NavigationRouter.appServices);
  }

  setOrderStatus(status) {
    setState(ViewState.loading);
    orderStatus = status;
    setState(ViewState.idle);
  }

  Future<void> openMap(double latitude, double longitude) async {
    String googleUrl =
        'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';
    print(googleUrl);
    if (await canLaunch(googleUrl)) {
      await launch(googleUrl);
    } else {
      throw 'Could not open the map.';
    }
  }

  getMyActiveRiders() async {
    setState(ViewState.loading);
    _userInfoModel = _authService.userInfoModel;
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    String token = sharedPreference.getString(
      SharedPreference.token,
    );
    print(_userInfoModel.store);
    BaseModel response =
        await _api.getMyActiveRiders(token, _userInfoModel.store);
    if (response.serverError == null) {
      ridersList = [];
      List responseList = jsonDecode(response.body);
      print(response.body);

      responseList.forEach((element) {
        ridersList.add(UserInfoModel.fromJson(element));
      });
      //storeName
      setState(ViewState.idle);
    } else {
      setState(ViewState.error);
    }
  }


  updateDriverStatus() async {
    setState(ViewState.loading);
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    String token = sharedPreference.getString(
      SharedPreference.token,
    );
    BaseModel response = await _api.updateRiderStatus(_userInfoModel.id, {"busy": false.toString()}, token);
    if (response.serverError == null) {
//      const snackBar = SnackBar(content: Text());
      Fluttertoast.showToast(
          msg: "Order status updated successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      return;
    } else {
      Fluttertoast.showToast(
          msg: "Unable to update order status",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
    print(response.body);
    setState(ViewState.idle);
  }

  getMyOrders() async {
    setState(ViewState.loading);
    _userInfoModel = _authService.userInfoModel;
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    String token = sharedPreference.getString(
      SharedPreference.token,
    );
    print(_userInfoModel.store);
    BaseModel response = await _api.getMyOrders(token, _userInfoModel.id);
    if (response.serverError == null) {
//        String response = response.;
      orderList = jsonDecode(response.body);
      orderList.forEach((element) {
        print(element['selectedTime']);
        print(element['orderStatus']);
      });
      //storeName
      setState(ViewState.idle);
    } else
      setState(ViewState.error);
  }

  updateOrder(String orderId, Map status) async {
    setState(ViewState.loading);
    _userInfoModel = _authService.userInfoModel;
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    String token = sharedPreference.getString(
      SharedPreference.token,
    );
    BaseModel response = await _api.updateOrder(token, orderId, status);
    orderStatus =
        OrderModel.fromJson(jsonDecode(response.body)["message"]).orderStatus;
    setState(ViewState.idle);
    //storeName
    getMyOrders();
  }

  updateStatus(String id, Map status) async {
    setState(ViewState.loading);
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    String token = sharedPreference.getString(
      SharedPreference.token,
    );
    BaseModel response = await _api.updateRiderStatus(id, status, token);
    if (response.serverError == null) {
//      const snackBar = SnackBar(content: Text());
      Fluttertoast.showToast(
          msg: "Order assigned successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
    } else {
      Fluttertoast.showToast(
          msg: "Unable to assign order at the moment",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
    print(response.body);
    setState(ViewState.idle);
  }
}
