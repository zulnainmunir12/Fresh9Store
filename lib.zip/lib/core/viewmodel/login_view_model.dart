import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fresh9_rider/core/model/base_model.dart';
import 'package:fresh9_rider/core/model/login_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fresh9_rider/core/enums/enums.dart';
import 'package:fresh9_rider/core/model/user_info_model.dart';
import 'package:fresh9_rider/core/service/api.dart';
import 'package:fresh9_rider/core/service/auth_service.dart';
import 'package:fresh9_rider/core/service/navigation_service.dart';
import 'package:fresh9_rider/core/viewmodel/custom_base_view_model.dart';
import 'package:fresh9_rider/locator.dart';
import 'package:fresh9_rider/ui/router.dart';
import 'package:fresh9_rider/ui/shared/shared_preference.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Create a [AndroidNotificationChannel] for heads up notifications
const AndroidNotificationChannel channel = AndroidNotificationChannel(
  'high_importance_channel', // id
  'High Importance Notifications', // title
  'This channel is used for important notifications.', // description
  importance: Importance.high,
);

/// Initialize the [FlutterLocalNotificationsPlugin] package.
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

class LoginViewModel extends CustomBaseViewModel {
  final NavigationService _navigationService = locator<NavigationService>();
  final AuthService _authService = locator<AuthService>();
  final Api _api = locator<Api>();
  bool _currentPasswordVisibility = false;

  bool get currentPasswordVisibility => _currentPasswordVisibility;

  String _token;

  LoginViewModel() {
    startUpProcess();
  }

  void setToken(String token) {
    print('FCM Token: $token');
    _token = token;
  }

  startUpProcess() {
    FirebaseMessaging.instance.getToken().then((token) {
      setToken(token);
    });
    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage message) {
      if (message != null) {
//        Navigator.pushNamed(context, '/message',
//            arguments: MessageArguments(message, true));
      }
    });

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      RemoteNotification notification = message.notification;
      AndroidNotification android = message.notification?.android;
      if (notification != null && android != null) {
        flutterLocalNotificationsPlugin.show(
            notification.hashCode,
            notification.title,
            notification.body,
            NotificationDetails(
              android: AndroidNotificationDetails(
                channel.id,
                channel.name,
                channel.description,
                // TODO add a proper drawable resource to android, for now using
                //      one that already exists in example app.
                icon: '@mipmap/ic_icon',
                largeIcon: DrawableResourceAndroidBitmap('@mipmap/ic_largeIcon'),
              ),
            ));
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('A new onMessageOpenedApp event was published!');
    });
  }

  changeCurrentPasswordVisibility() {
    _currentPasswordVisibility = !_currentPasswordVisibility;
    notifyListeners();
  }

  bool _enableFingerPrint = false;

  get enableFingerPrint => _enableFingerPrint;

  setFingerPrint(bool value) {
    _enableFingerPrint = value;
    notifyListeners();
  }

  login(Map accountData, GlobalKey<ScaffoldState> scaffoldKey) async {
    setState(ViewState.loading);

    LoginModel loginModelData = await _authService.loginCustomer(accountData);
//    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
//    String apiToken = sharedPreference.getString(SharedPreference.token);
    if (loginModelData.serverError == null) {
      if (loginModelData.success) {
        print("Successfully Logged In");
        await saveToken(loginModelData.token);
        BaseModel userResponse = await _api.updateRiderStatus(
            loginModelData.userInfo.id,
            {"pushToken": _token},
            loginModelData.token);

        _navigationService.navigateToAndClearAll(NavigationRouter.appServices);
      } else {
//        print(accountData);
//        if(accountData == null)
//          accountData = {"phone": phone};
//        else
//             accountData["phone"] = phone;

//        await saveToken(loginModelData.token);
//        _navigationService.navigateToAndClearAll(NavigationRouter.signUpScreen,
//            arguments: accountData);
        setState(ViewState.idle);
        const snackBar = SnackBar(content: Text("User not found"));
        scaffoldKey.currentState.showSnackBar(snackBar);
      }
    } else {
      final snackBar = SnackBar(content: Text("User not found"));
      scaffoldKey.currentState.showSnackBar(snackBar);
      setServerError(loginModelData.serverError);
      setState(ViewState.error);
    }
  }

  saveToken(String token) async {
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    await sharedPreference.remove(SharedPreference.token);
    await sharedPreference.setString(
      SharedPreference.token,
      token,
    );
    print("Saved token - $token");
  }

  onTapLogin() {
    _navigationService.navigateTo(NavigationRouter.enterNumberScreen);
  }

  onTapForgotPassword() {
//    _navigationService.navigateToAndBack(NavigationRouter.);
  }
}
