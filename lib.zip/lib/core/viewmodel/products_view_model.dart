import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:fresh9_rider/core/model/base_model.dart';
import 'package:fresh9_rider/core/model/product.dart';
import 'package:fresh9_rider/core/model/user_info_model.dart';
import 'package:fresh9_rider/core/service/api.dart';
import 'package:fresh9_rider/core/enums/enums.dart';
import 'package:fresh9_rider/core/service/auth_service.dart';
import 'package:fresh9_rider/core/service/navigation_service.dart';
import 'package:fresh9_rider/core/viewmodel/custom_base_view_model.dart';
import 'package:fresh9_rider/locator.dart';
import 'package:fresh9_rider/ui/router.dart';
import 'package:fresh9_rider/ui/shared/shared_preference.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProductsViewModel extends CustomBaseViewModel {
  final NavigationService _navigationService = locator<NavigationService>();
  final AuthService _authService = locator<AuthService>();
  final Api _api = locator<Api>();
  UserInfoModel _userInfoModel;

  UserInfoModel get userInfoModel => _userInfoModel;
  List<Product> productssList = [];

  ProductsViewModel() {
    getMyProductss();
  }

  getMyProductss() async {
    setState(ViewState.loading);
    _userInfoModel = _authService.userInfoModel;
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    String token = sharedPreference.getString(
      SharedPreference.token,
    );
    print(_userInfoModel.store);
    BaseModel response = await _api.getMyProducts(token, _userInfoModel.store);
    if (response.serverError == null) {
      productssList = [];
      List responseList = jsonDecode(response.body);
      print(response.body);

      responseList.forEach((element) {
        productssList.add(Product.fromJson(element));
      });
      //storeName
      setState(ViewState.idle);
    } else {
      setState(ViewState.error);
    }
  }

  updateStatus(String id, String productId) async {
    setState(ViewState.loading);
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    String token = sharedPreference.getString(
      SharedPreference.token,
    );
    BaseModel response =
        await _api.updateProductStatus(id, productId, {"inventory": 0.toString()}, token);
    if (response.serverError == null) {
//      const snackBar = SnackBar(content: Text());
      Fluttertoast.showToast(
          msg: "Product status updated successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      getMyProductss();
      return;
    } else {
      Fluttertoast.showToast(
          msg: "Unable to update product status",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
    print(response.body);
    setState(ViewState.idle);
  }
}
