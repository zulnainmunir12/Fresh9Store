import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:fresh9_rider/core/model/base_model.dart';
import 'package:fresh9_rider/core/model/order_model.dart';
import 'package:fresh9_rider/core/model/user_info_model.dart';
import 'package:fresh9_rider/core/service/api.dart';
import 'package:fresh9_rider/core/enums/enums.dart';
import 'package:fresh9_rider/core/service/auth_service.dart';
import 'package:fresh9_rider/core/service/navigation_service.dart';
import 'package:fresh9_rider/core/viewmodel/custom_base_view_model.dart';
import 'package:fresh9_rider/locator.dart';
import 'package:fresh9_rider/ui/router.dart';
import 'package:fresh9_rider/ui/shared/shared_preference.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DashboardViewModel extends CustomBaseViewModel {
  final NavigationService _navigationService = locator<NavigationService>();
  final AuthService _authService = locator<AuthService>();
  final Api _api = locator<Api>();
  UserInfoModel _userInfoModel;

  UserInfoModel get userInfoModel => _userInfoModel;

  DashboardViewModel() {
    getInformation();
  }

  getInformation() async {
    setState(ViewState.loading);
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    String token = sharedPreference.getString(
      SharedPreference.token,
    );
    BaseModel response = await _api.getUserInfo(token);
    if (response.serverError == null) {
      print(response.body.storeDetail.breakStatus);
      _userInfoModel = response.body;
    }
    setState(ViewState.idle);
  }

  updateStatus(String id, bool status) async {
    setState(ViewState.loading);
    SharedPreferences sharedPreference = await SharedPreferences.getInstance();
    String token = sharedPreference.getString(
      SharedPreference.token,
    );
    BaseModel response =
        await _api.updateStoreStatus(id, {"break": status.toString()}, token);
    if (response.serverError == null) {
//      const snackBar = SnackBar(content: Text());
      Fluttertoast.showToast(
          msg: "Break status updated successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      getInformation();
      return;
    } else {
      Fluttertoast.showToast(
          msg: "Unable to update break status",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
    print(response.body);
    setState(ViewState.idle);
  }
}
