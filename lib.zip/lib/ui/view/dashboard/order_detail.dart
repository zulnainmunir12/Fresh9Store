import 'package:fresh9_rider/core/enums/enums.dart';
import 'package:fresh9_rider/core/model/order_model.dart';
import 'package:fresh9_rider/core/model/user_info_model.dart';
import 'package:fresh9_rider/core/service/navigation_service.dart';
import 'package:fresh9_rider/core/viewmodel/order_view_model.dart';
import 'package:fresh9_rider/locator.dart';
import 'package:fresh9_rider/ui/shared/app_colors.dart';
import 'package:fresh9_rider/ui/shared/font_size.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fresh9_rider/ui/shared/loading.dart';
import 'package:fresh9_rider/ui/widget/vertical_spacing.dart';
import 'package:stacked/stacked.dart';

class OrderDetailPage extends StatefulWidget {
  OrderModel order;
  OrderDetailPage(this.order, {Key key}) : super(key: key);
  @override
  _ArrivedOrder createState() => _ArrivedOrder();
}

class _ArrivedOrder extends State<OrderDetailPage> {
  final NavigationService _navigationService = locator<NavigationService>();
  int total = 0;

  calculateDeliveryFee() {
    total = 0;
    widget.order.products.forEach((element) {
      if (element.discountedPrice != null && element.discountedPrice != 0)
        total += (element.discountedPrice * element.quantity);
      else
        total += (element.retailPrice * element.quantity);
    });
    return widget.order.total == 0
        ? (widget.order.wallet - total).toString()
        : ((widget.order.total - total) <= 0
                ? (widget.order.total - total) +
                    (widget.order.wallet == null ? 0 : widget.order.wallet)
                : (widget.order.total - total))
            .toString();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print(widget.order.orderType);
  }

//  void errorDialog(BuildContext context, String orderId, OrderViewModel model) {
//    Dialog errorDialog = Dialog(
//      shape: RoundedRectangleBorder(
//          borderRadius: BorderRadius.circular(12.0)), //this right here
//      child: Container(
//        height: 150.0,
//        width: 350.0,
//        child: Column(
//          mainAxisAlignment: MainAxisAlignment.center,
//          children: <Widget>[
//            const Padding(
//              padding: EdgeInsets.only(top: 1),
//              child: Text(
//                'Do you want to cancel',
//                style: TextStyle(fontSize: FontSize.l),
//              ),
//            ),
//            Padding(
//              padding: EdgeInsets.only(bottom: 10),
//              child: Text(
//                'Order # ' + orderId.substring(0, 8),
//                style: TextStyle(fontSize: FontSize.xl),
//              ),
//            ),
//            VerticalSpacing(height: 0.02),
//            Row(
//              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//              children: [
//                OutlineButton(
//                    shape: RoundedRectangleBorder(
//                        borderRadius: BorderRadius.circular(20)),
//                    onPressed: () {
//                      Navigator.pop(context);
//                    },
//                    child: const Text(
//                      'No',
//                      style: TextStyle(
//                          color: AppColor.greenColor, fontSize: FontSize.l),
//                    )),
//                OutlineButton(
//                    shape: RoundedRectangleBorder(
//                        borderRadius: BorderRadius.circular(20)),
//                    onPressed: () {
//                      Navigator.pop(context, true);
//                    },
//                    child: Text(
//                      'Yes',
//                      style: TextStyle(
//                          color: AppColor.redColor, fontSize: FontSize.l),
//                    )),
//              ],
//            )
//          ],
//        ),
//      ),
//    );
//    showDialog(context: context, builder: (BuildContext context) => errorDialog)
//        .then((value) {
//      if (value == true) model.updateOrder(orderId, "dropped");
//    });
//  }

  String _selected;
//

  Future _chooseRider(context, OrderViewModel model) async {
    return await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
            title: Text("Choose Rider"),
            actions: <Widget>[
              FlatButton(
                color: Colors.red,
                textColor: Colors.white,
                child: Text('CANCEL'),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              FlatButton(
                color: Colors.green,
                textColor: Colors.white,
                child: Text('CONFIRM'),
                onPressed: () {
                  setState(() {
//                    codeDialog = valueText;
                    Navigator.pop(context, true);
                  });
                },
              ),
            ],
            content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
                //your code dropdown button here
                DropdownButton(
                    value: _selected,
                    items: model.ridersList.map((UserInfoModel value) {
                      return DropdownMenuItem<String>(
                        value: value.id,
                        child: Text(value.fullname),
                      );
                    }).toList(),
                    hint: Text('Pick Rider'),
                    onChanged: (value) {
                      print(value);
                      setState(() {
                        _selected = value;
                      });
                    }),
              ]);
            }));
      },
    ).then((value) {
      if (value == true) {
        model.updateStatus(_selected,
            {"orderAssigned": widget.order.id, "busy": true.toString()});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder.reactive(
        viewModelBuilder: () => OrderViewModel(),
        onModelReady: (OrderViewModel model) async {
          await model.getMyActiveRiders();
          await model.setOrderStatus(widget.order.orderStatus);
        },
        builder: (context, OrderViewModel model, child) {
          return model.state == ViewState.loading
              ? Loading.normalLoading()
              : Scaffold(
                  appBar: AppBar(
                    actions: [
                      model.orderStatus == "delivered"
                          ? Container()
                          : IconButton(
                              icon: const Icon(
                                Icons.location_on,
                                color: AppColor.primaryColor,
                              ),
                              onPressed: () {
                                if (model.orderStatus == "confirmed") {
                                  model.openMap(
                                      double.tryParse(widget
                                          .order.storeLocation["latitude"]),
                                      double.tryParse(widget
                                          .order.storeLocation["longitude"]));
                                } else {
                                  model.openMap(widget.order.userLocation[0],
                                      widget.order.userLocation[1]);
                                  print(widget.order.userLocation);
                                }
                              }),

                      //
                      //deliveryTime
//                      model.orderStatus == "confirmed" ||
//                              model.orderStatus == "picked"
//                          ? IconButton(
//                              icon: const Icon(
//                                Icons.check,
//                                color: AppColor.secondaryColor,
//                              ),
//
//                          : Container(),
                    ],

//        leading:
                    title: Text(
                      'Order Details (' + widget.order.id.substring(0, 8) + ")",
                      style: TextStyle(color: AppColor.darkGrey),
                    ),
                  ),
                  body: Container(
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                    child: Column(
                      children: [
                        Text(
                          widget.order.customerName,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          widget.order.customerMobile,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          widget.order.addressDetail,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          widget.order.deliveryAddress,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          widget.order.addressType,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        widget.order.addressInstructions == ""
                            ? Container()
                            : Text(
                                widget.order.addressInstructions,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold),
                              ),
                        Text(
                          model.orderStatus.substring(0, 1).toUpperCase() +
                              model.orderStatus.substring(1),
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700),
                        ),
                        Text(
                          widget.order.selectedTime,
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          width: MediaQuery.of(context).size.width,
                          height: 1,
                          color: AppColor.primaryColor,
                        ),
                        widget.order.orderType == 'Store'
                            ? Container()
                            : Text(
                                widget.order.title,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: FontSize.xl,
                                    fontWeight: FontWeight.bold),
                              ),
                        widget.order.orderType == 'Store'
                            ? Flexible(
                                child: ListView.builder(
                                itemCount: widget.order.products.length,
                                itemBuilder: (BuildContext context, int index) {
                                  return Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.7,
                                            child: Text(
                                              widget.order.products[index]
                                                      .quantity
                                                      .toString() +
                                                  " * " +
                                                  widget.order.products[index]
                                                      .name,
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.w700),
                                            ),
                                          ),
                                          Text(
                                            "Rs. " +
                                                (widget.order.products[index]
                                                            .quantity *
                                                        widget
                                                            .order
                                                            .products[index]
                                                            .discountedPrice)
                                                    .toString(),
                                            style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w700),
                                          )
                                        ],
                                      ),
                                      Divider()
                                    ],
                                  );
                                },
                              ))
                            : Flexible(child: Text(widget.order.instructions)),
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          width: MediaQuery.of(context).size.width,
                          height: 1,
                          color: AppColor.primaryColor,
                        ),
                        widget.order.orderType == 'Store'
                            ? Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Delivery Fee: ",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  Text(
                                    "Rs. " + calculateDeliveryFee(),
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              )
                            : Container(),
                      ],
                    ),
                  ),
                  bottomNavigationBar: InkWell(
                      onTap: () {
                        if (model.orderStatus != "delivered") {
                          if (model.orderStatus == "picked") {
                            model.updateDriverStatus();
                          }
                          model.updateOrder(
                              widget.order.id,
                              model.orderStatus == "confirmed"
                                  ? {
                                      "orderStatus": "picked",
                                      "pickupTime": DateTime.now().toString()
                                    }
                                  : {
                                      "orderStatus": "delivered",
                                      "deliveryTime": DateTime.now().toString()
                                    });
                        }
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 15),
                        color: AppColor.primaryColor,
                        height: widget.order.orderType == 'Store' ? 50 : 0,
                        width: MediaQuery.of(context).size.width,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              model.orderStatus == "delivered"
                                  ? "Delivered"
                                  : model.orderStatus == "confirmed"
                                      ? "Picked"
                                      : "On Way",
                              style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                  color: AppColor.whiteColor),
                            ),
                            Text(
                              "(Rs. " + widget.order.total.toString() + ")",
                              style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                  color: AppColor.whiteColor),
                            ),
                          ],
                        ),
                      )));
        });
  }
}
