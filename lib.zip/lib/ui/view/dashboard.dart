import 'package:flutter/material.dart';
import 'package:fresh9_rider/core/enums/enums.dart';
import 'package:fresh9_rider/core/service/api.dart';
import 'package:fresh9_rider/core/service/auth_service.dart';
import 'package:fresh9_rider/core/viewmodel/dashboard_view_model.dart';
import 'package:fresh9_rider/locator.dart';
import 'package:fresh9_rider/ui/shared/app_colors.dart';
import 'package:fresh9_rider/ui/shared/loading.dart';
import 'package:fresh9_rider/ui/view/dashboard/orders.dart';
import 'package:fresh9_rider/ui/view/dashboard/products.dart';
import 'package:fresh9_rider/ui/view/dashboard/riders.dart';
import 'package:stacked/stacked.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DahboardScreenViewState createState() => _DahboardScreenViewState();
}

class _DahboardScreenViewState extends State<DashboardScreen> {
  int _selectedIndex = 0; //New
  final AuthService _authService = locator<AuthService>();
  final Api _api = locator<Api>();
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  final List<Widget> _tabs = [ProductsView(), MyOrderView(), RidersView()];

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder.reactive(
        viewModelBuilder: () => DashboardViewModel(),
        onModelReady: (DashboardViewModel model) async {
//    await model.getMyActiveRiders();
//    await model.setOrderStatus(widget.order.orderStatus);
        },
        builder: (context, DashboardViewModel model, child) {
          return model.state == ViewState.loading
              ? Loading.normalLoading()
              : Scaffold(
                  appBar: AppBar(
                    centerTitle: true,
                    title: const Text(
                      'Dashboard',
                      style: TextStyle(color: AppColor.blackColor),
                    ),
                    actions: [

                      IconButton(
                          onPressed: () async {
                            await _authService.clearAuthService();
                          },
                          icon: const Icon(Icons.exit_to_app))
                    ],
                  ),
                  body: MyOrderView()
//                  bottomNavigationBar: BottomNavigationBar(
//                    currentIndex: _selectedIndex,
//                    onTap: _onItemTapped,
//                    items: const <BottomNavigationBarItem>[
//                      BottomNavigationBarItem(
//                        icon: Icon(Icons.production_quantity_limits),
//                        label: 'Products',
//                      ),
//                      BottomNavigationBarItem(
//                        icon: Icon(Icons.bookmark_border),
//                        label: 'Orders',
//                      ),
//                      BottomNavigationBarItem(
//                        icon: Icon(Icons.people),
//                        label: 'Riders',
//                      ),
//                    ],
//                  ),
                  );
        });
  }
}
