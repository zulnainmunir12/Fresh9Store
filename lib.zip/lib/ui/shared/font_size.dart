class FontSize {
  static const double s = 12;
  static const double m = 14;
  static const double l = 16;
  static const double xl = 18;
  static const double xxl = 20;
  static const double xxxl = 22;
  static const double xxxxl = 24;
  static const double xxxxxxl = 40;
}